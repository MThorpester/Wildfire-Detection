// API key
const API_KEY = "pk.eyJ1IjoibXRob3JwZXN0ZXIiLCJhIjoiY2tuZmF5MHB4MDc5eTJwbndnbjVzYXVqZSJ9.7hFfJ-9YnLi6nOpSaFGAdw";
